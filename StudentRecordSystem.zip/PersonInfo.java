public interface PersonInfo {
    void displayBasicInfo();
    String getType();
}