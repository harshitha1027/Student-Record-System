public class Student extends Record implements PersonInfo {
    private int studentId;
    private String name;
    private int marks;
    private String section;
    private boolean isPassed;
    private StringBuilder remarks;
    private static int studentCount = 0;
    public static final String INSTITUTE_NAME = "Smartex Institute";

    public Student() {
        studentCount++;
        remarks = new StringBuilder();
    }

    public Student(int studentId, String name, int marks, String section) throws InvalidMarksException {
        if (marks < 0 || marks > 100) throw new InvalidMarksException("Marks must be between 0 and 100");
        this.studentId = studentId;
        this.name = name;
        this.marks = marks;
        this.section = section;
        this.isPassed = marks >= 40;
        remarks = new StringBuilder();
        studentCount++;
    }

    public Student(Student s) {
        this.studentId = s.studentId;
        this.name = s.name;
        this.marks = s.marks;
        this.section = s.section;
        this.isPassed = s.isPassed;
        this.remarks = new StringBuilder(s.remarks.toString());
        studentCount++;
    }

    public void printDetails() {
        System.out.println("ID: " + studentId + ", Name: " + name + ", Marks: " + marks +
                           ", Section: " + section + ", Passed: " + isPassed + ", Remarks: " + remarks);
    }

    public String calculateGrade() {
        int m = this.marks;
        if (m >= 90) return "A";
        else if (m >= 75) return "B";
        else if (m >= 60) return "C";
        else if (m >= 40) return "D";
        else return "F";
    }

    public void markAsPassed() {
        this.isPassed = this.marks >= 40;
    }

    public void appendRemarks(String remark) {
        remarks.append(remark).append(" ");
    }

    public void compareNames(String otherName) {
        System.out.println("Using == : " + (this.name == otherName));
        System.out.println("Using equals(): " + this.name.equals(otherName));
    }

    public static int getStudentCount() {
        return studentCount;
    }

    @Override
    public final void finalizeRecord() {
        System.out.println("Finalizing record of student: " + name);
    }

    @Override
    public void displayBasicInfo() {
        System.out.println("ID: " + studentId + ", Name: " + name);
    }

    @Override
    public String getType() {
        return "Regular Student";
    }

    public int getMarks() {
        return marks;
    }

    public String getName() {
        return name;
    }
}