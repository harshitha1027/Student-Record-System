public class ScholarStudent extends Student {
    private int scholarshipAmount;

    public ScholarStudent(int studentId, String name, int marks, String section, int scholarshipAmount)
            throws InvalidMarksException {
        super(studentId, name, marks, section);
        this.scholarshipAmount = scholarshipAmount;
    }

    @Override
    public String calculateGrade() {
        int newMarks = getMarks() + 5;
        if (newMarks > 100) newMarks = 100;
        if (newMarks >= 90) return "A";
        else if (newMarks >= 75) return "B";
        else if (newMarks >= 60) return "C";
        else if (newMarks >= 40) return "D";
        else return "F";
    }

    @Override
    public String getType() {
        return "Scholar Student";
    }
}