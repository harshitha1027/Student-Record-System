import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class StudentApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();
        boolean running = true;

        while (running) {
            System.out.println("\n--- Welcome to Smartex Student System ---");
            System.out.println("1. Add Student");
            System.out.println("2. Display Student Details");
            System.out.println("3. Append Remarks");
            System.out.println("4. Calculate Grade");
            System.out.println("5. Compare Names");
            System.out.println("6. Simulate Exception");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Is Scholar Student? (yes/no): ");
                        String scholar = sc.nextLine();
                        System.out.print("Enter ID: ");
                        int id = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter Name: ");
                        String name = sc.nextLine();
                        System.out.print("Enter Marks: ");
                        int marks = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter Section: ");
                        String section = sc.nextLine();

                        if (scholar.equalsIgnoreCase("yes")) {
                            System.out.print("Enter Scholarship Amount: ");
                            int amount = sc.nextInt();
                            sc.nextLine();
                            students.add(new ScholarStudent(id, name, marks, section, amount));
                        } else {
                            students.add(new Student(id, name, marks, section));
                        }
                        break;

                    case 2:
                        for (Student s : students) {
                            s.printDetails();
                        }
                        break;

                    case 3:
                        System.out.print("Enter student index: ");
                        int idx1 = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter remark: ");
                        String remark = sc.nextLine();
                        students.get(idx1).appendRemarks(remark);
                        break;

                    case 4:
                        System.out.print("Enter student index: ");
                        int idx2 = sc.nextInt();
                        sc.nextLine();
                        System.out.println("Grade: " + students.get(idx2).calculateGrade());
                        break;

                    case 5:
                        System.out.print("Enter student index: ");
                        int idx3 = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter name to compare: ");
                        String cmp = sc.nextLine();
                        students.get(idx3).compareNames(cmp);
                        break;

                    case 6:
                        try {
                            int x = 5 / 0;
                        } catch (ArithmeticException e) {
                            System.out.println("Exception caught: " + e.getMessage());
                        } finally {
                            System.out.println("Exception handling demo completed.");
                        }
                        break;

                    case 7:
                        running = false;
                        System.out.println("Exiting...");
                        break;

                    default:
                        System.out.println("Invalid choice!");
                }
            } catch (InvalidMarksException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (IndexOutOfBoundsException e) {
                System.out.println("Invalid student index.");
            } catch (InputMismatchException e) {
                System.out.println("Invalid input type.");
                sc.nextLine(); // clear buffer
            }
        }
        sc.close();
    }
}